import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-short-popup',
  templateUrl: './item-short-popup.component.html',
  styleUrls: ['./item-short-popup.component.scss']
})
export class ItemShortPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
