import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-delivery',
  templateUrl: './confirm-delivery.component.html',
  styleUrls: ['./confirm-delivery.component.scss']
})
export class ConfirmDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
