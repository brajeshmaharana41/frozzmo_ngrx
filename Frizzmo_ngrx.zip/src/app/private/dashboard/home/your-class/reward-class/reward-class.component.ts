import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reward-class',
  templateUrl: './reward-class.component.html',
  styleUrls: ['./reward-class.component.scss']
})
export class RewardClassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
