import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invite-tech',
  templateUrl: './invite-tech.component.html',
  styleUrls: ['./invite-tech.component.scss']
})
export class InviteTechComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
