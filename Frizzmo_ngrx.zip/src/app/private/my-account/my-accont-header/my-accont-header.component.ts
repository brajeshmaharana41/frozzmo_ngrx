import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-accont-header',
  templateUrl: './my-accont-header.component.html',
  styleUrls: ['./my-accont-header.component.scss']
})
export class MyAccontHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
