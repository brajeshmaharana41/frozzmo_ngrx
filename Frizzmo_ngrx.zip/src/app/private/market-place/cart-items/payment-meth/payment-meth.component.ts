import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-meth',
  templateUrl: './payment-meth.component.html',
  styleUrls: ['./payment-meth.component.scss']
})
export class PaymentMethComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
