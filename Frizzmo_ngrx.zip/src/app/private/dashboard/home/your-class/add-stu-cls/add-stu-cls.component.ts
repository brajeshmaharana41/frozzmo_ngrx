import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-stu-cls',
  templateUrl: './add-stu-cls.component.html',
  styleUrls: ['./add-stu-cls.component.scss']
})
export class AddStuClsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
