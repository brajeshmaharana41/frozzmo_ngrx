import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-address-book',
  templateUrl: './add-address-book.component.html',
  styleUrls: ['./add-address-book.component.scss']
})
export class AddAddressBookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
