import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-re-update-cls',
  templateUrl: './re-update-cls.component.html',
  styleUrls: ['./re-update-cls.component.scss']
})
export class ReUpdateClsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
