import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-cls',
  templateUrl: './add-new-cls.component.html',
  styleUrls: ['./add-new-cls.component.scss']
})
export class AddNewClsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
