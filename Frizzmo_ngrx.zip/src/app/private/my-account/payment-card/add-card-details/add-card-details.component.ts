import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-card-details',
  templateUrl: './add-card-details.component.html',
  styleUrls: ['./add-card-details.component.scss']
})
export class AddCardDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
