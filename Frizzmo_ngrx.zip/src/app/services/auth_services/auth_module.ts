export interface SignUP {
    firstname: string
    lastname: string
    middlename: string
    emailAddress: string
    phoneNumber: string
    password: string
    deviceType: string
    deviceId: string
    isPrimary: boolean
  }
  