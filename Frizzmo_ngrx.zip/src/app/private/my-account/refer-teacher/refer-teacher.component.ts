import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refer-teacher',
  templateUrl: './refer-teacher.component.html',
  styleUrls: ['./refer-teacher.component.scss']
})
export class ReferTeacherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
