import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketing-preferences',
  templateUrl: './marketing-preferences.component.html',
  styleUrls: ['./marketing-preferences.component.scss']
})
export class MarketingPreferencesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
