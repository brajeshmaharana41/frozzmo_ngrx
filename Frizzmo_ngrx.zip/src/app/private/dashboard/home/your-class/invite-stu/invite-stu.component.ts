import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invite-stu',
  templateUrl: './invite-stu.component.html',
  styleUrls: ['./invite-stu.component.scss']
})
export class InviteStuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
