import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-giveback',
  templateUrl: './giveback.component.html',
  styleUrls: ['./giveback.component.scss']
})
export class GivebackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
