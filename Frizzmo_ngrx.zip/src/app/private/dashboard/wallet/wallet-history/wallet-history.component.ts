import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wallet-history',
  templateUrl: './wallet-history.component.html',
  styleUrls: ['./wallet-history.component.scss']
})
export class WalletHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
